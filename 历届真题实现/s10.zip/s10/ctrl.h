#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction4(u8 i);
void adda_ctrl();
void shuma_show();
void led_show();

#endif