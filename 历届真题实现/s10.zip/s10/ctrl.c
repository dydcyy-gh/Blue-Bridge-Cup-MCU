#include <STC15F2K60S2.H>
#include "typedef.h"
#include "pcf8591.h"
#include "shuma.h"

bit key_s4_flag = 0;//0=U,i=F
bit key_s5_flag = 0;//2.0
bit key_s6_flag = 0;//led on
bit key_s7_flag = 0;//shuma on

extern bit flag_ADC;
extern u8 shumatmp[];
extern u16 FreqCnt;//频率计数

u16 ADC_V = 0;

//按键行为函数
void keyaction4(u8 i)
{
	switch(i)
	{
		case 0:
			if(key_s4_flag) key_s4_flag = 0;
			else key_s4_flag = 1;
			break;
		case 1:
			if(key_s5_flag) key_s5_flag = 0;
			else key_s5_flag = 1;
			break;
		case 2:
			if(key_s6_flag) key_s6_flag = 0;
			else key_s6_flag = 1;
			break;
		case 3:
			if(key_s7_flag) key_s7_flag = 0;
			else key_s7_flag = 1;
			break;
	}
}

void adda_ctrl()
{
	u8 ADC;
	if(flag_ADC == 1)
	{
		flag_ADC = 0;
		ADC = adc(0x03);
		ADC_V = ADC/0.51;
		if(key_s5_flag == 0)
		{
			dac(102);
		}
		if(key_s5_flag == 1)
		{
			dac(ADC);
		}
	}
}

void shuma_show()
{
	u8 i;
	if(key_s7_flag == 0)
	{
		if(key_s4_flag == 0)
		{
			shumatmp[0] = 20;
			shumatmp[1] = 23;
			shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			if(ADC_V>=100)
				warma(6,ADC_V);
			else
			{
				shumatmp[5] = 0;
				warma(7,ADC_V);
			}
				
		}
		if(key_s4_flag == 1)
		{	
			shumatmp[0] = 15;
			shumatmp[1] = 23;
			warma(3,FreqCnt);
		}
	}
	if(key_s7_flag == 1)
	{
		for(i=0;i<8;i++)
		{
			shumatmp[i] = 23;
		}
	}
}

void led_show()
{
	if(key_s6_flag == 0)
	{
		if(key_s4_flag == 0)
		{
			if(ADC_V<=150||(ADC_V<350&&ADC_V>=250))//1111 1110
			{
				P2=(P2&0x1f)|0x80;
				P0 = 0xfe;
				P2&=0x1f;
			}
			else//1111 1010
			{
				P2=(P2&0x1f)|0x80;
				P0 = 0xfa;
				P2&=0x1f;
			}
			
		}
		if(key_s4_flag == 1)
		{
			if(FreqCnt<1000||(FreqCnt>=5000&&FreqCnt<10000))//1111 1101
			{
				P2=(P2&0x1f)|0x80;
				P0 = 0xfd;
				P2&=0x1f;
			}
			else//1111 0101
			{
				P2=(P2&0x1f)|0x80;
				P0 = 0xf5;
				P2&=0x1f;
			}
		}
	}
	if(key_s6_flag == 1)
	{
		P2=(P2&0x1f)|0x80;
		P0=0xff;
		P2&=0x1f;
	}
}