#include "typedef.h"

#ifndef __TIMER0_H__
#define __TIMER0_H__

void timer0init();
	
#endif