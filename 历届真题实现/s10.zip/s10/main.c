#include <STC15F2K60S2.H>
#include "typedef.h"
#include "timer1.h"
#include "shuma.h"
#include "4key.h"
#include "timer0.h"
#include "ctrl.h"

bit flag_ADC;
u16 FreqCnt;//频率计数
extern bit key_s4_flag;//0=U,i=F

void main()
{
	timer1init(2);
	timer0init();
	while(1)
	{
		adda_ctrl();
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count=200;
	static u8 cnt=0;
	static u16 AllTime = 0;	
	cnt++;
	if(key_s4_flag == 0)
	{
		count++;
		if(count>200)
		{
			count=0;
			flag_ADC = 1;
		}
	}
	if(key_s4_flag == 1)
	{
		if(AllTime == 0)          //ALLTime为计时的变量
		{
			TR0 = 1;                 //计数器0开启计数
			AllTime++;
		}
		else if(AllTime < 500)  //如果小于1s钟的话
		{
			AllTime++;
		}
		else                        //如果1s到了的话
		{
			AllTime = 0;            //清空计时变量
			TR0 = 0;                //停止计时
			FreqCnt = (((u16)TH0 << 8) |(u16)TL0); //将脉冲频率取出
			TH0 = 0;                //清除脉冲计数现有值，做好初始化
			TL0 = 0;
		}
	}
	if(cnt>50)
	{
		cnt = 0;
		shuma_show();
		led_show();
	}
	shumascan();
	keyscan4();
}