#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "at24c02.h"
#include "pcf8591.h"
#include "ds18b20.h"
#include "wave.h"
#include "uart1timer2.h"
#include <string.h>

extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

bit key_s12_flag = 0;//数据-0  参数-1
u8  key_s13_flag = 0;//f0-l1-q2   0s1-1s2
bit key_s16_flag = 0;//-
bit key_s17_flag = 0;//+

extern bit dac_flag;
extern bit clear_flag;

bit eeprom_flag = 0;
u16 t_ral;//55.55
u8  t_ral_h;
u8  t_ral_l;
u8  l_ral;
u16 count_change = 0;
u8  t_set = 30;
u8  l_set = 35;
u8  t_old = 30;
u8  l_old = 35;

u8 Rxdata[10] = {'\0'};
u8 a[] = "ST\r\n";
u8 b[] = "PARA\r\n";

//按键行为函数
void keyaction16(u8 i)
{
	switch(i)
	{
		case 12:
			if(key_s12_flag == 1)
			{
				key_s12_flag = 0;
				key_s13_flag = 0;
				eeprom_flag = 1;
			}
			else 
			{
				key_s12_flag = 1;
				key_s13_flag = 0;
			}
			break;
		
		case 13:
			if(key_s13_flag == 5) key_s13_flag = 0;
			else key_s13_flag++;
			break;
	
		case 16:
			key_s16_flag = 1;
			break;
		
		case 17:
			key_s17_flag = 1;
			break;
		
		default:
			break;
	}
}
void read_t()//300ms
{
	t_ral = (u16)(100.00*ds18b20_read_tempeture());
}

void read_l()//500ms
{
	l_ral = receive_wave()+3;
}

void eeprom_record()//@100ms
{
	if(clear_flag == 1)
	{
		clear_flag = 0;
		count_change = 0;
		AT24C02_WriteByte(0x01,count_change);
	}
	if(eeprom_flag == 1)
	{
		eeprom_flag = 0;
		if(t_old != t_set || l_old != l_set)
		{
			count_change++;
			AT24C02_WriteByte(0x01,count_change);
			t_old = t_set;
			l_old = l_set;
		}
	}
}

void uart_action()
{
	if(Uart_WaitRecive() == 0)
	{
		 if(strcmp(Rxdata,a)==0)
		 {
			 t_ral_h = t_ral/100;
             t_ral_l = t_ral%100;
			 SendData('$');
			 SendData(l_ral/10+48);
			 SendData(l_ral%10+48);
			 SendData('.');
			 SendData(t_ral_h/10+48);
			 SendData(t_ral_h%10+48);
			 SendData(t_ral_l/10+48);
			 SendData(t_ral_l%10+48);
			 SendData('\r');
			 SendData('\n');
		 }
		 else if(strcmp(Rxdata,b)==0)
		 {
			 SendData('$');
			 SendData(l_set/10+48);
		     SendData(l_set%10+48);
			 SendData('.');
			 SendData(t_set/10+48);
		     SendData(t_set%10+48);
			 SendData('\r');
			 SendData('\n');
		 }
		 else
		 {
			 SendString("error\r\n");
		 }
	}
}

void dac_output()//@100ms
{
	if(dac_flag == 0)
	{
		if(l_ral <= l_set) dac(102);
		else dac(204);
	}
	if(dac_flag == 1)
	{
		dac(20);
	}
}

//根据按键状态刷新状态，进行数码管显示
void shuma_exchange_ctrl()//@100ms
{
	if(key_s12_flag == 0)
	{
		if(key_s13_flag == 0 || key_s13_flag == 3)
		{
			shumatmp[0] = 15;
			shumatmp[1] = 23;
			shumatmp[2] = 23;
			shumatmp[3] = 23;
			warma_add_zero(5,4,t_ral);
		}
		if(key_s13_flag == 1 || key_s13_flag == 4)
		{
			shumatmp[0] = 17;
			shumatmp[1] = 23;
			shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			shumatmp[5] = 23;
			warma_add_zero(7,2,l_ral);
		}
		if(key_s13_flag == 2 || key_s13_flag == 5)
		{
			shumatmp[0] = 24;
			shumatmp[1] = 23;
			shumatmp[2] = 23;
			warma_none_zero(4,5,count_change);
		}
	}
	if(key_s12_flag == 1)
	{
		shumatmp[0] = 19;
		shumatmp[1] = 23;
		shumatmp[2] = 23;
		shumatmp[4] = 23;
		shumatmp[5] = 23;
		if(key_s13_flag == 0 || key_s13_flag == 2 || key_s13_flag == 4)
		{
			shumatmp[3] = 1;
			warma_add_zero(7,2,t_set);
		}
		if(key_s13_flag == 1 || key_s13_flag == 3 || key_s13_flag == 5)
		{
			shumatmp[3] = 2;
			warma_add_zero(7,2,l_set);
		}
	}	
	if(key_s16_flag == 1 && key_s12_flag == 1)
	{
		key_s16_flag = 0;
		if(key_s13_flag == 0 || key_s13_flag == 2 || key_s13_flag == 4) t_set -= 2;
		if(key_s13_flag == 1 || key_s13_flag == 3 || key_s13_flag == 5) l_set -= 5;
	}
	if(key_s17_flag == 1 && key_s12_flag == 1)
	{
		key_s17_flag = 0;
		if(key_s13_flag == 0 || key_s13_flag == 2 || key_s13_flag == 4) t_set += 2;
		if(key_s13_flag == 1 || key_s13_flag == 3 || key_s13_flag == 5) l_set += 5;
	}
}

//led刷新
void led_scan()//@100ms
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

//led显示控制
void led_ctrl()//@100ms
{
	if(t_ral > t_set) ledtmp[0] = 0x00;
	else ledtmp[0] = 0xff;
	if(l_ral < l_set) ledtmp[1] = 0x00;
	else ledtmp[1] = 0xff;
	if(dac_flag == 0) ledtmp[2] = 0x00;
	else ledtmp[2] = 0xff;
}