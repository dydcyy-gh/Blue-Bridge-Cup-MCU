#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction16(u8 i);
void read_t();//300ms
void read_l();//500ms
void eeprom_record();//@100ms
void dac_output();//@100ms
void led_scan();//@100ms
void led_ctrl();//@100ms
void uart_action();//@100ms
void shuma_exchange_ctrl();//@100ms

#endif