#include <STC15F2K60S2.H>
#include "ctrl.h"
#include "typedef.h"

//矩阵键盘用此声明
//IN给零，OUT为0即为按下
sbit key_in_3 = P3^2;//5  9  13 17
sbit key_in_4 = P3^3;//4  8  12 16
sbit key_out_3 = P3^5; //15 14 13 12
sbit key_out_4 = P3^4; //19 18 17 16

//矩阵键盘含义数组
u8 keymap[2][2] ={
	{13,17},
	{12,16}
};

u16 count1 = 0;
u16 count2 = 0;
bit dac_flag = 0;
bit clear_flag = 0;

//矩阵键盘扫描函数(在中断调用)
//扫描一轮耗时x*8*4ms（建议中断x=1ms）
void keyscan16()
{
	u8 i;
	static u8 key = 0;
	//2*8ms延时判断
	static u8 keytmp[2][2] = {{0xff,0xff},{0xff,0xff}};
	//防重复对比数组
	static u8 keyold[2][2] = {{1,1},{1,1}};
	static u8 keynow[2][2] = {{1,1},{1,1}};
		
	switch(key)//打开一路并关闭上一轮打开的
	{
		case 0: key_in_3 = 0; key_in_4 = 1; break;
		case 1: key_in_4 = 0; key_in_3 = 1; break;
		default : break;
	}

	keytmp[key][0] = (keytmp[key][0]<<1)| key_out_3;
	keytmp[key][1] = (keytmp[key][1]<<1)| key_out_4;
	
	for(i=0;i<2;i++)
	{
		if(keytmp[key][i] == 0xff)
		{
			keynow[key][i] = 1;
		}
		else if(keytmp[key][i] == 0x00)
		{
			keynow[key][i] = 0;
		}
		else {}
	}
	for(i=0;i<2;i++)
	{
		//短按控制
		if(keynow[key][i]!=keyold[key][i])
		{
			if(keynow[key][i]==0)
			{
				keyaction16(keymap[key][i]);
			}
			keyold[key][i]=keynow[key][i];
		}
	}
	
	if(keynow[0][0] == 0)//13
		count1++;
	if(count1>500) 
	{
		if(dac_flag==0) dac_flag = 1;
		else dac_flag = 0;
		count1 = 0;
	}
	
	if(keynow[1][0] == 0)//12
		count2++;
	if(count2>500) {clear_flag = 1; count2 = 0;}
	
	if(key == 1) key = 0;
	else key = 1;
}

