#include <STC15F2K60S2.H>
#include "typedef.h"
#include "pwmtimer2.h"
#include "4key.h"
#include "shuma.h"
#include "timer1.h"
#include "ctrl.h"
#include "at24c02.h"

bit u1flag = 0;
bit u2flag = 0;
bit u3flag = 0;
bit u4flag = 0;
extern u8 relay_count;

void main()
{
	relay_count = AT24C02_ReadByte(0x00);
	timer2init();
	timer1init(2);
	while(1)
	{
		if(u1flag == 1)
		{
			u1flag = 0;
			adda_ctrl();
		}
		if(u2flag == 1)
		{
			u2flag = 0;
			wave_ctrl();
		}
		if(u3flag == 1)
		{
			u3flag = 0;
			led_scan();
			led_ctrl();
		}
		if(u4flag == 1)
		{
			u4flag = 0;
			shuma_exchange_ctrl();
		}
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count1=0;
	static u8 count2=0;
	static u8 count3=0;
	static u8 count4=0;
	count1++;
	count2++;
	count3++;
	count4++;
	if(count1>49)
		{count1=0;u1flag = 1;}
	if(count2>49)
		{count2=0;u2flag = 1;}
	if(count3>49)
		{count3=0;u3flag = 1;}
	if(count4>49)
		{count4=0;u4flag = 1;}
	shumascan();
	keyscan4();
}

//这里是定时器2（pwm）中断函数
void interrupttimer2() interrupt 12
{
	pwm_ctrl();
}
