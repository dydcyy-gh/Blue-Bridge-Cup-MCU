#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction4(u8 i);
void pwm_ctrl();
void adda_ctrl();
void wave_ctrl();
void led_scan();
void led_ctrl();
void shuma_exchange_ctrl();

#endif