#include <STC15F2K60S2.H>
#include "typedef.h"
#include "4key.h"
#include "shuma.h"
#include "at24c02.h"
#include "wave.h"
#include "pcf8591.h"

extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

u8  key_s4_flag = 0;//界面切换
u8  key_s5_flag = 0;//参数切换
bit key_s6_flag = 0;//+1 
bit key_s7_flag = 0;//-1 

bit len_ex_flag = 0;// 0-cm,1-m
bit khz_ex_flag = 0;// 0-hz,1-khz

u8 khz10_set = 90;//khz*10
u8 wet_set = 40;
u8 cmlen_set = 60;//cm

u16 hz_now;
u8  wet_now;
u8  cmlen_now;

u8 relay_count = 0;
extern bit long_s7_flag;

//按键行为函数
void keyaction4(u8 i)
{
	switch(i)
	{
		case 0:
			if(key_s4_flag == 3) key_s4_flag = 0;
		    else key_s4_flag ++;
			break;
		
		case 1:
			if(key_s4_flag == 3)
			{
				if(key_s5_flag == 2) key_s5_flag = 0;
				else key_s5_flag ++;
			}
			break;
		
		case 2:
			if(key_s4_flag == 3)
			{
				switch(key_s5_flag)
				{
					case 0:
						if(khz10_set == 120) khz10_set = 10;
						else if(khz10_set < 120) khz10_set += 5;
					break;
					
					case 1:
						if(wet_set == 60) wet_set = 10;
						else if(wet_set < 60)  wet_set += 10;
					break;
					
					case 2:
						if(cmlen_set == 120) cmlen_set = 10;
						else if(cmlen_set < 120) cmlen_set += 10;
					break;
					
					default:break;
				}
			}
			if(key_s4_flag == 2)
			{
				if(len_ex_flag == 0) len_ex_flag = 1;
				else len_ex_flag = 0;
			}
			break;
		
		case 3:
			if(key_s4_flag == 3)
			{
				switch(key_s5_flag)
				{
					case 0:
						if(khz10_set == 10) khz10_set = 120; 
						else if(khz10_set > 10) khz10_set -= 5; 
					break;
					
					case 1:
						if(wet_set == 10) wet_set = 60;
						else if(wet_set > 10) wet_set -= 10;
					break;
					
					case 2:
						if(cmlen_set == 10) cmlen_set = 120;
						else if(cmlen_set > 10) cmlen_set -= 10;
					break;
					
					default:break;
				}
			}
			if(key_s4_flag == 0)
			{
				if(khz_ex_flag == 0) khz_ex_flag = 1;
				else khz_ex_flag = 0;
			}
			break;
		
		default:
			break;
	}
}


//直流电机
void motor(u8 a)
{
	P2=(P2&0x1f)|0xa0;
	P04=0;//关继电器
	P05=a;//a=0,输出1
	P06=0;//关蜂鸣器
	P2&=0x1f;
}

//pwm计算函数  定时器10us（100000hz）
//max（最大精度）:建议10（T=100us）-100（T=1ms）
//ex（占空比）：Ton/T  ex/max
void pwm (u8 max,u8 ex)
{
	static u8 cnt = 0;
	if(cnt == ex)
	{
		motor(1);
	}
	if(cnt < max)
		cnt++;
	else
	{
		motor(0);
		cnt = 0;
	}
}

void pwm_ctrl()
{
	if(khz10_set*100 < hz_now) pwm(100,80);
	else pwm(100,20);
}

void adda_ctrl()
{
	u8 i;
	do {
        i = adc(0x03);
    } while (i == 0);
	wet_now = i/2.55;
	if(i <= 51) dac(51);
	if(i >= 204) dac(255);
	if(i>51&&i<204) dac(153);
}

void wave_ctrl()
{
	do {
        cmlen_now = receive_wave();
    } while (cmlen_now == 0);
	
	if(cmlen_now > cmlen_set)
	{
		P2=(P2&0x1f)|0xa0;
		P04=1;P06=0;
		P2&=0x1f;
		relay_count++;
		AT24C02_WriteByte(0x00,relay_count);
	}
	else
	{
		P2=(P2&0x1f)|0xa0;
		P04=0;P06=0;
		P2&=0x1f;
	}
	if(long_s7_flag == 1)
	{
		long_s7_flag = 0;
		relay_count = 0;
		AT24C02_WriteByte(0x00,relay_count);
	}
}

//led刷新
void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

//led显示控制
void led_ctrl()//@100ms @timer1
{
	static u8 i = 0x00;
	if(i == 0x00) i = 0xff;
	else i = 0x00;
	switch(key_s4_flag)
	{
		case 0:
			ledtmp[0] = i;
			break;
		case 1:
			ledtmp[1] = i;
			break;
		case 2:
			ledtmp[2] = i;
			break;
	}
	if(hz_now > khz10_set*100) ledtmp[3] = 0x00;
	else ledtmp[3] = 0xff;
	if(wet_now > wet_set) ledtmp[3] = 0x00;
	else ledtmp[3] = 0xff;
	if(cmlen_now > cmlen_set) ledtmp[3] = 0x00;
	else ledtmp[3] = 0xff;
}

void shuma_exchange_ctrl()//@100ms @timer1
{
	switch(key_s4_flag)
	{
		case 0:
			shumatmp[0] = 15;
			shumatmp[1] = 23;
			if(khz_ex_flag == 0) warma_none_zero(3,6,hz_now);
			else warma_none_zero(3,6,hz_now/100);
			break;
		case 1:
			shumatmp[0] = 16;shumatmp[1] = 23;shumatmp[2] = 23;
			shumatmp[3] = 23;shumatmp[4] = 23;shumatmp[5] = 23;
			warma_none_zero(7,2,wet_now);
			break;
		case 2:
			shumatmp[0] = 10;
			shumatmp[1] = 23;shumatmp[2] = 23;
			shumatmp[3] = 23;shumatmp[4] = 23;
			if(len_ex_flag == 0) warma_none_zero(6,3,cmlen_now);
			else warma_add_zero(3,6,cmlen_now);
			break;
		case 3:
			shumatmp[0] = 19;
			shumatmp[2] = 23;shumatmp[3] = 23;shumatmp[4] = 23;
			switch(key_s5_flag)
			{
				case 0:
					shumatmp[1] = 1;
					warma_none_zero(6,3,khz10_set);
					break;
				case 1:
					shumatmp[1] = 2;
					shumatmp[5] = 23;
					warma_none_zero(7,2,wet_set);
					break;
				case 2:
					shumatmp[1] = 3;
					shumatmp[5] = 23;
					warma_add_zero(7,2,cmlen_set/10);
					break;
			}
			break;
	}
}
