#include "typedef.h"

#ifndef __4KEY_H__
#define __4KEY_H__

void keyscan4();

#endif
