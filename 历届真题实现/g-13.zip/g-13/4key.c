//独立按键长按，短按控制
#include <STC15F2K60S2.H>
#include "ctrl.h"
#include "typedef.h"

//读出的值为0即为按下
sbit KEY_IN_1 = P3^3;sbit KEY_IN_2 = P3^2;
sbit KEY_IN_3 = P3^1;sbit KEY_IN_4 = P3^0;

bit long_s7_flag = 0;

u16 keytimelen[4]={0,0,0,0};//长按时间

//独立按键扫描函数(在中断调用)
void keyscan4()
{
	static u16 count;
	u8 i;
	//2*8ms延时判断
	static u8 keytmp[4] = {0xff,0xff,0xff,0xff};
	//防止重复对比
	static u8 keyold[4] = {1,1,1,1};
	static u8 keynow[4] = {1,1,1,1};
	
	keytmp[0] = (keytmp[0]<<1)| KEY_IN_1;
	keytmp[1] = (keytmp[1]<<1)| KEY_IN_2;
	keytmp[2] = (keytmp[2]<<1)| KEY_IN_3;
	keytmp[3] = (keytmp[3]<<1)| KEY_IN_4;
	
	for(i=0;i<4;i++)
	{
		if(keytmp[i] == 0xff)
			keynow[i] = 1;
		if(keytmp[i] == 0x00)
			keynow[i] = 0;
	}
	
	for(i=0;i<4;i++)
	{		
		if(keyold[i]==0 && keynow[i]==1) keyaction4(i);
		
		if(keyold[3]==0 && keynow[3]==0) count++;
		else count = 0;
		
		if(count>60 && keynow[3]==1)
		{
			long_s7_flag = 1;
			count = 0;
		}

		keyold[i]=keynow[i];
	}
}