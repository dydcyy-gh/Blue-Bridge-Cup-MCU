#include "typedef.h"

#ifndef __PWMTIMER2_H__
#define __PWMTIMER2_H__

void timer2init();

#endif