#ifndef __DS18B20_H__
#define __DS18B20_H__

float ds18b20_read_tempeture();

#endif