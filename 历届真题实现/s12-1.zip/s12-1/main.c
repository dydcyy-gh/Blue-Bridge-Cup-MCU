#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "timer1.h"
#include "ctrl.h"

bit flag1 = 0;
bit flag2 = 0;

void main()
{
	timer1init(2);
	while(1)
	{
		if(flag1 == 1)
		{
			flag1 = 0;
			shuma_C();
		}
		if(flag2 == 1)
		{
			flag2 = 0;
			shuma_A();
		}
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count1=0;
	static u8 count2=0;
	static u8 count3=0;
	static u8 count4=0;
	static u8 count5=0;
	count1++;
	if(count1>=150)
		{count1=0;flag1 = 1;}
	count2++;
	if(count2>=50)
		{count2=0;shuma_P();}
	count3++;
	if(count3>=150)
		{count3=0;flag2 = 1;}
	count4++;
	if(count4>=50)
		{count4=0;led_ctrl();led_scan();}
	count5++;
	if(count5>=100)
		{count5=0;shuma_exchange_ctrl();}
	shumascan();
	keyscan16();
}