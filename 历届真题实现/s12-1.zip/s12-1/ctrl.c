#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "pcf8591.h"
#include "ds18b20.h"

extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};//led乱闪解决：放数组里

u8 key_s5_flag = 0;//0-modle1  1-modle2
u8 key_s4_flag = 0;//0-C  1-P  2-A
u8 key_s9_flag = 0;//+
u8 key_s8_flag = 0;//-

u16 real_tmp;
u8 set_tmp = 25;
u8 DAC;
u16 Vdac;

//按键行为函数（示例为数码管增加数字）
void keyaction16(u8 i)
{
	switch(i)
	{
		case 5://0-modle1  1-modle2
			if(key_s5_flag == 1) key_s5_flag = 0;
			else key_s5_flag = 1;
			i=0;
			break;
		
		case 4://0-C  1-P  2-A
			if(key_s4_flag == 2) key_s4_flag = 0;
			else key_s4_flag++;
		    i=0;
			break;
		
		case 9://+
			key_s9_flag = 1;
		    i=0;
			break;
		
		case 8://-
			key_s8_flag = 1;
		    i=0;
			break;
		
		default:
			break;
	}
}

void shuma_C()//@300ms @main
{
	float temp;
	temp = ds18b20_read_tempeture();
	if(temp<0) temp = 0-temp;
	real_tmp = (u16)(temp*100);
}

void shuma_P()//@100ms @timer1
{
	if(key_s4_flag == 1)
	{
		if(key_s9_flag ==1)
		{
			key_s9_flag = 0;
			set_tmp++;
		}
		if(key_s8_flag ==1)
		{
			key_s8_flag = 0;
			set_tmp--;
		}
	}
}

void shuma_A()//@300ms @main
{	
	if(key_s5_flag == 0)//0-modle1  
	{
		if(real_tmp<set_tmp*100) DAC = 0;
		else DAC = 255;
	}
	if(key_s5_flag == 1)//1-modle2
	{
		if(real_tmp<=2000) DAC = 51;
		if(real_tmp>2000&&real_tmp<=4000) DAC = real_tmp*153/20-102;
		if(real_tmp>=4000) DAC = 204;
	}
	dac(DAC);
	Vdac = (DAC/0.51);
}

void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;  
}

void led_ctrl()//@100ms @timer1
{
	if(key_s5_flag == 0) ledtmp[0] = 0x00;
	else ledtmp[0] = 0xff;
	if(key_s4_flag == 0) ledtmp[1] = 0x00;
	else ledtmp[1] = 0xff;
	if(key_s4_flag == 1) ledtmp[2] = 0x00;
	else ledtmp[2] = 0xff;
	if(key_s4_flag == 2) ledtmp[3] = 0x00;
	else ledtmp[3] = 0xff;
}

void shuma_exchange_ctrl()//@200ms @timer1
{
	switch(key_s4_flag)
	{
		case 0://0-C
			shumatmp[0] = 12;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			warma(5,4,real_tmp);
			break;
		
		case 1://1-P
			shumatmp[0] = 19;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
		    shumatmp[5] = 23;
			warma(7,2,set_tmp);
			break;
		
		case 2://2-A
			shumatmp[0] = 10;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			warma(6,3,Vdac);
			break;
		
		default:
			break;
	}
}