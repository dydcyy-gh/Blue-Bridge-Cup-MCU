#include <STC15F2K60S2.H>
#include "shuma.h"
#include "typedef.h"
#include "ctrl.h"

//in44 out32 s5
//in44 out33 s4
//in42 out32 s9
//in42 out33 s8

//矩阵键盘用此声明
//IN给零，OUT为0即为按下
sbit KEY_OUT_32 = P3^2;
sbit KEY_OUT_33 = P3^3;
sbit KEY_IN_42 = P4^2;
sbit KEY_IN_44 = P4^4;

//矩阵键盘含义数组
u8 keymap[2][2] ={
	{5, 9},
	{4, 8},
};

//矩阵键盘扫描函数(在中断调用)
//扫描一轮耗时x*8*4ms（建议中断x=1ms）
void keyscan16()
{
	u8 i;
	static u8 keyout = 0;
	//2*8ms延时判断
	static u8 keytmp[2][2] = {{0xff,0xff},{0xff,0xff}};
	//防重复对比数组
	static u8 keyold[2][2] = {{1,1},{1,1}};
	static u8 keynow[2][2] = {{1,1},{1,1}};
		
	switch(keyout)//打开一路并关闭上一轮打开的
	{
		case 0: KEY_OUT_32 = 0; KEY_OUT_33 = 1; break;
		case 1: KEY_OUT_33 = 0; KEY_OUT_32 = 1; break;
		default : break;
	}
	
	keytmp[keyout][0] = (keytmp[keyout][0]<<1)| KEY_IN_44;
	keytmp[keyout][1] = (keytmp[keyout][1]<<1)| KEY_IN_42;
	
	for(i=0;i<2;i++)
	{
		if(keytmp[keyout][i] == 0xff)
		{
			keynow[keyout][i] = 1;
		}
		else if(keytmp[keyout][i] == 0x00)
		{
			keynow[keyout][i] = 0;
		}
		else {}
	}
	
	for(i=0;i<2;i++)
	{
		//短按控制
		if(keynow[keyout][i]!=keyold[keyout][i])
		{
			if(keynow[keyout][i]==0)
			{
				keyaction16(keymap[keyout][i]);
			}
			keyold[keyout][i]=keynow[keyout][i];
		}
	}
	
	if(keyout == 1) keyout = 0;
	else keyout++;
}