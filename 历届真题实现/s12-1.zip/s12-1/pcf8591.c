#include <STC15F2K60S2.H>
#include "iic.h"
#include "typedef.h"
#include "shuma.h"

#define ADDRESS	0x90//pcf8591写地址

//DA：数字（计算机）->模拟（外设）（电压）
//输出DAC 0~255 to 0~5V
void dac(u8 DAC)
{
	I2CStart();	//发送IIC开始信号
	I2CSendByte(ADDRESS);	//发送写命令
	I2CWaitAck();
	I2CSendByte(0x40);  //写控制字:使能DAC输出
	I2CWaitAck();
	I2CSendByte(DAC);	//写DAC值
	I2CWaitAck();
	I2CStop();//产生停止信号
}