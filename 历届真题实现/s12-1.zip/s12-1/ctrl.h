#include "typedef.h"

#ifndef __DS18B20_H__
#define __DS18B20_H__

void keyaction16(u8 i);
void shuma_C();
void shuma_P();
void shuma_A();
void led_scan();
void led_ctrl();
void shuma_exchange_ctrl();
	
#endif