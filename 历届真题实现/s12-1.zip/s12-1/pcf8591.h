#include "typedef.h"

#ifndef __PCF8591_H__
#define __PCF8591_H__

void dac(u8 DAC);
	
#endif