#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction16(u8 i);
void shuma_U1();//@500ms @main
void shuma_U2();//@200ms @main
void shuma_U3();//@100ms @timer1
void led_scan();//@100ms @timer1
void led_ctrl();//@100ms @timer1
void relay_ctrl();//@100ms @timer1
void shuma_exchange_ctrl();//@300ms @timer1
	
#endif