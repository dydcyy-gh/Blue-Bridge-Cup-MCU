#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "ds18b20.h"
#include "ds1302.h"

extern u8 ALL1302[];
extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
//led乱闪解决：放数组里

bit key_s13_flag = 0;//0-tmp ctrl 1-time ctrl @all
u8  key_s12_flag = 0;//0-U1  1-U2  2-U3  exchange @all
bit key_s17_flag = 0;//-1  @u3
bit key_s16_flag = 0;//+1  @u3

u16 t_now;//@*100!
u8 t_set = 23;//@*1
bit key17flag = 0;
u8 u2_show1;
u8 u2_show2;
bit oclock = 0;
bit relayon = 0;

//按键行为函数（示例为数码管增加数字）
void keyaction16(u8 i)
{
	switch(i)
	{
		case 13:
			if(key_s13_flag == 1) key_s13_flag = 0;
			else key_s13_flag = 1;
			break;
		
		case 12:
			if(key_s12_flag == 2) key_s12_flag = 0;
			else key_s12_flag++;
			break;
		
		case 17:
			key_s17_flag = 1;
			break;
		
		case 16:
			key_s16_flag = 1;
			break;
		
		default:
			break;
	}
}

void shuma_U1()//@500ms @main
{
	t_now =(u16)(ds18b20_read_tempeture()*10);
}

void shuma_U2()//@200ms @main
{
	DS1302_ReadTime();
	if(key17flag == 1)
	{
		u2_show1 = ALL1302[4];
		u2_show2 = ALL1302[5];
	}
	else
	{
		u2_show1 = ALL1302[3];
		u2_show2 = ALL1302[4];
	}
	if(ALL1302[4]==0 && ALL1302[5]==0)
		oclock = 1;
	if(ALL1302[4]==0 && ALL1302[5]==5)
		oclock = 0;
}

void shuma_U3()//@100ms @timer1
{
	if(key_s12_flag == 2)
	{
		if(key_s17_flag == 1)
		{
			key_s17_flag = 0;
            t_set--;
		}
		if(key_s16_flag == 1)
		{
			key_s16_flag = 0;
            t_set++;
		}
	}
}

void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

void led_ctrl()//@100ms @timer1
{
	bit a = 0;
	if(oclock == 1)
	{
		ledtmp[0] = 0x00;
	}
	else ledtmp[0] = 0xff;
    if(key_s13_flag == 0)
	{
		ledtmp[1] = 0x00;
	}
	else ledtmp[1] = 0xff;
	if(relayon == 1)
	{
		if(a == 0) {ledtmp[2] = 0xff;a = 1;}
		else {ledtmp[2] = 0x00;a = 0;}
	}
}

void relay(u8 i)//1 on  0 off
{
	P2=(P2&0x1f)|0xa0;
	P04=i;//继电器
	P06=0;
	P2&=0x1f;
	relayon = i;
}

void relay_ctrl()//@100ms @timer1
{
	if(key_s13_flag == 0)//tempeture
	{
		if((t_now > (t_set*10)) && relayon == 0)
		{
			relay(1);
		}
		if((t_now <= (t_set*10)) && relayon == 1)
		{
			relay(0);
		}
	}
	if(key_s13_flag == 1)//time
	{
		if(oclock == 1 && relayon == 0)
		{
			relay(1);
	    }
		if(oclock == 0 && relayon == 1)
		{
			relay(0);
		}
	}
}

void shuma_exchange_ctrl()//@300ms @timer1
{
	switch(key_s12_flag)
	{
		case 0://0-U1
			shumatmp[0] = 20;
			shumatmp[1] = 1;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			warma_add_zero(6,3,t_now);
			break;
		
		case 1://1-U2
			shumatmp[0] = 20;
			shumatmp[1] = 2;
		    shumatmp[2] = 23;
			warma_add_zero(4,2,u2_show1);
			shumatmp[5] = 21;
			warma_add_zero(7,2,u2_show2);
			break;
		
		case 2://2-U3
			shumatmp[0] = 20;
			shumatmp[1] = 3;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			shumatmp[5] = 23;
			warma_add_zero(7,2,t_set);
			break;
		
		default:
			break;
	}
}