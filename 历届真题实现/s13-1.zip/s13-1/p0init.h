#ifndef __P0INIT_H__
#define __P0INIT_H__

void p0init();

#endif