#include <STC15F2K60S2.H>
#include "shuma.h"
#include "typedef.h"
#include "ctrl.h"

//in35 out32 s13
//in35 out33 s12
//in34 out32 s17
//in34 out33 s16

//矩阵键盘用此声明
//IN给零，OUT为0即为按下
sbit KEY_OUT_32 = P3^2;
sbit KEY_OUT_33 = P3^3;
sbit KEY_IN_34 = P3^4;
sbit KEY_IN_35 = P3^5;

//矩阵键盘含义数组
u8 keymap[2][2] ={
	{13, 17},
	{12, 16},
};

extern bit key17flag;

//矩阵键盘扫描函数(在中断调用)
//扫描一轮耗时x*8*4ms（建议中断x=1ms）
void keyscan16()
{
	u8 i;
	static u8 keyout = 0;
	//2*8ms延时判断
	static u8 keytmp[2][2] = {{0xff,0xff},{0xff,0xff}};
	//防重复对比数组
	static u8 keyold[2][2] = {{1,1},{1,1}};
	static u8 keynow[2][2] = {{1,1},{1,1}};
		
	switch(keyout)//打开一路并关闭上一轮打开的
	{
		case 0: KEY_OUT_32 = 0; KEY_OUT_33 = 1; break;
		case 1: KEY_OUT_33 = 0; KEY_OUT_32 = 1; break;
		default : break;
	}
	
	keytmp[keyout][0] = (keytmp[keyout][0]<<1)| KEY_IN_35;
	keytmp[keyout][1] = (keytmp[keyout][1]<<1)| KEY_IN_34;
	
	for(i=0;i<2;i++)
	{
		if(keytmp[keyout][i] == 0xff)
		{
			keynow[keyout][i] = 1;
		}
		else if(keytmp[keyout][i] == 0x00)
		{
			keynow[keyout][i] = 0;
		}
		else {}
	}
	
	for(i=0;i<2;i++)
	{
		//短按控制
		if(keynow[keyout][i]!=keyold[keyout][i])
		{
			if(keynow[keyout][i]==0)
			{
				keyaction16(keymap[keyout][i]);
			}
			keyold[keyout][i]=keynow[keyout][i];
		}
	}
	if(keyout == 1) keyout = 0;
	else keyout++;
	
	if(keynow[0][1]==0)
	{
		key17flag = 1;
	}
	else key17flag = 0;
}