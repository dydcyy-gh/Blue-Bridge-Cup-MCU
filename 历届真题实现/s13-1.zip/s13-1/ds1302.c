#include <STC15F2K60S2.H>
#include "intrins.h"
#include "typedef.h"
#include "shuma.h"

//引脚定义
sbit SCK = P1^7;//sclk
sbit SDA = P2^3;//io
sbit RST = P1^3;//ce

//寄存器写入地址/指令定义
#define sec		0x80
#define min		0x82
#define hour	0x84
#define day 	0x86
#define month	0x88
#define week	0x8A
#define year	0x8C
#define wp		0x8E

//时间数组，索引0~6分别为年、月、日、时、分、秒、星期
u8 ALL1302[]={19,11,16,12,59,55,6};

//发送一个字节到通信总线上（已给出）
void Write_Ds1302(u8 temp) 
{
	u8 i;
	for (i=0;i<8;i++)     	
	{ 
		SCK = 0;
		SDA = temp&0x01;
		temp>>=1; 
		SCK=1;
	}
}   

//向某一寄存器中写入，address表示寄存器地址，dat为待写入字节（已给出）
void Write_Ds1302_Byte( u8 address,u8 dat )     
{
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1; 	_nop_();  
 	Write_Ds1302(address);	
 	Write_Ds1302(dat);		
 	RST=0; 
}

//从某一寄存器中读出一个字节，address表示寄存器地址（已给出）
u8 Read_Ds1302_Byte ( u8 address )
{
 	u8 i,temp=0x00;
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1;	_nop_();
 	Write_Ds1302(address);
 	for (i=0;i<8;i++) 	
 	{		
		SCK=0;
		temp>>=1;	
 		if(SDA)
 		temp|=0x80;	
 		SCK=1;
	} 
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
	SCK=1;	_nop_();
	SDA=0;	_nop_();
	SDA=1;	_nop_();
	return (temp);			
}

//ds1302初始化并设置初始时间
void DS1302_SetTime(void)
{
	RST=0;  _nop_();
	SCK=0;  _nop_();
	Write_Ds1302_Byte(wp,   0x00);
	Write_Ds1302_Byte(year, ALL1302[0]/10*16 + ALL1302[0]%10);
	Write_Ds1302_Byte(month,ALL1302[1]/10*16 + ALL1302[1]%10);
	Write_Ds1302_Byte(day,  ALL1302[2]/10*16 + ALL1302[2]%10);
	Write_Ds1302_Byte(hour, ALL1302[3]/10*16 + ALL1302[3]%10);
	Write_Ds1302_Byte(min,  ALL1302[4]/10*16 + ALL1302[4]%10);
	Write_Ds1302_Byte(sec,  ALL1302[5]/10*16 + ALL1302[5]%10);
	Write_Ds1302_Byte(week, ALL1302[6]/10*16 + ALL1302[6]%10);
	Write_Ds1302_Byte(wp,   0x80);
}

//DS1302读取时间，数据会被读取到ALL1302数组中
void DS1302_ReadTime(void)
{
	u8 Temp;
	Temp = Read_Ds1302_Byte(year|0x01);
	ALL1302[0] = Temp/16*10+Temp%16;
	Temp = Read_Ds1302_Byte(month|0x01);
	ALL1302[1] = Temp/16*10+Temp%16;
	Temp = Read_Ds1302_Byte(day|0x01);
	ALL1302[2] = Temp/16*10+Temp%16;
	Temp = Read_Ds1302_Byte(hour|0x01);
	ALL1302[3] = Temp/16*10+Temp%16;
	Temp = Read_Ds1302_Byte(min|0x01);
	ALL1302[4] = Temp/16*10+Temp%16;
	Temp = Read_Ds1302_Byte(sec|0x01);
	ALL1302[5] = Temp/16*10+Temp%16;
	Temp = Read_Ds1302_Byte(week|0x01);
	ALL1302[6] = Temp/16*10+Temp%16;
}