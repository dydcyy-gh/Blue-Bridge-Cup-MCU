#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "pcf8591.h"
#include "ds1302.h"
#include "ds18b20.h"

extern u8 ALL1302[];
extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
//led乱闪解决：放数组里

u8  key_s4_flag = 0;//界面切换
u8  key_s5_flag = 0;//回显切换
bit key_s8_flag = 0;//+1 
bit key_s9_flag = 0;//-1 

extern bit long_key_flag;
u8 now_tempeture;
u8 now_humidity;
u8 last_tempeture;
u8 last_humidity;
u8 set_tempeture = 30;
bit humidity_flag = 0;
bit flag3s = 0;
bit record_fun_flag = 0;
u8 reflush_count = 0;
u8 last_time_hour;
u8 last_time_min;
u8 max_humidity;
u8 max_tempeture;
u16 per_humidity;
u16 per_tempeture;

//按键行为函数（示例为数码管增加数字）
void keyaction16(u8 i)
{
	switch(i)
	{
		case 4:
			if(key_s4_flag == 2) key_s4_flag = 0;
			else key_s4_flag++;
			break;
		
		case 5:
			if(key_s5_flag == 2) key_s5_flag = 0;
			else key_s5_flag++;
			break;
		
		case 8:
			key_s8_flag = 1;
			break;
		
		case 9:
			key_s9_flag = 1;
			break;
		
		default:
			break;
	}
}

void show_humidity()//all time @timer1
{
	static u16 AllTime = 0;
	u16 FreqCnt;
	if(humidity_flag == 1)
	{
		if(AllTime == 0)          //ALLTime为计时的变量
		{
			TR0 = 1;                 //计数器0开启计数
			AllTime++;
		}
		else if(AllTime < 500)  //如果小于1s钟的话
		{
			AllTime++;
		}
		else                        //如果1s到了的话
		{
			AllTime = 0;            //清空计时变量
			TR0 = 0;                //停止计时
			FreqCnt = (((u16)TH0 << 8) |(u16)TL0); //将脉冲频率取出
			TH0 = 0;                //清除脉冲计数现有值，做好初始化
			TL0 = 0;
			humidity_flag = 0;
		}
		now_humidity = (FreqCnt*2)/45+1;
	}
}

void record_fun()//100ms @timer1
{
	if(record_fun_flag == 1 && flag3s == 0)
	{
		static u16 sum_tempeture = 0;
		static u16 sum_humidity = 0;
		
		last_tempeture = now_tempeture;
		last_humidity = now_humidity;
		
		if(last_humidity > now_humidity)
			max_humidity = last_humidity;
		else max_humidity = now_humidity;
		
		if(last_tempeture > now_tempeture)
			max_tempeture = last_tempeture;
		else max_tempeture = now_tempeture;
		
		sum_tempeture += now_tempeture;
		per_tempeture = (sum_tempeture*10)/reflush_count;
		
		sum_humidity += now_humidity;
		per_humidity = (sum_humidity*10)/reflush_count;
		
		last_time_hour = ALL1302[3];
		last_time_min  = ALL1302[4];
		
		record_fun_flag = 0;
	}
}

void start_reflash()//200ms @main
{
	static u8 adc_now;
	static u8 adc_before;
	static u8 count = 0;
	if(flag3s == 0)
	{
		adc_now = adc(0x01);
		adc_before = adc_now;
	}
	if((long_key_flag == 1)&&(flag3s == 0))
	{
		long_key_flag = 0;
		humidity_flag = 1;
		now_tempeture = ds18b20_read_tempeture();
		reflush_count++;
		record_fun_flag = 1;
		flag3s = 1;
	}
	if(flag3s == 1)
	{
		count++;
		if(count>13) {flag3s = 0;count = 0;}
	}
}


void show_time()//200ms @main
{
	DS1302_ReadTime();
}

void set_tempeture_ctrl()//100ms @timer1
{
	if(key_s4_flag == 2)
	{
		if(key_s8_flag ==1)
		{
			set_tempeture++;
			key_s8_flag = 0;
		}
		if(key_s9_flag ==1)
		{
			set_tempeture--;
			key_s9_flag = 0;
		}
	}
}
	
void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

void led_ctrl()//@100ms @timer1
{
	static bit shift = 0;
	if(key_s4_flag == 0)
	    ledtmp[0] = 0;
	else ledtmp[0] = 1;
	
	if(key_s4_flag == 1)
	    ledtmp[1] = 0;
	else ledtmp[1] = 1;
	
	if(flag3s == 1)
		ledtmp[2] = 0;
	else ledtmp[2] = 1;
	
	if(now_tempeture > set_tempeture)
	{
		ledtmp[3] = shift;
		if(shift) shift = 0;else shift = 1;
	}
	
	if(now_humidity == 0||now_humidity>90||now_humidity<10)
	{
		ledtmp[4] = 0;
	}
	else ledtmp[4] = 1;
	
	if(now_tempeture>last_tempeture && now_humidity>last_humidity)
	{
		ledtmp[5] = 0;
	}
	else ledtmp[5] = 1;
}

void shuma_exchange_ctrl()//@300ms @timer1
{
	if(flag3s == 1)//E
	{
		shumatmp[0] = 14;
		shumatmp[1] = 23;
		shumatmp[2] = 23;
		warma_add_zero(4,2,now_tempeture);
		shumatmp[5] = 21;
		if(now_humidity == 0||now_humidity>90||now_humidity<10)
		{
			shumatmp[6] = 10;
			shumatmp[7] = 10;
		}
		else warma_add_zero(7,2,now_humidity);
	}
	else
	{
		switch(key_s4_flag)
		{
			case 0://time
				warma_add_zero(1,2,ALL1302[3]);
				shumatmp[2] = 21;
				warma_add_zero(4,2,ALL1302[4]);
				shumatmp[5] = 21;
				warma_add_zero(7,2,ALL1302[5]);
				break;
			
			case 1://back_show
				switch(key_s5_flag)
				{
					case 0://C
						shumatmp[0] = 12;
						shumatmp[1] = 23;
						warma_add_zero(3,2,max_tempeture);
						shumatmp[4] = 21;
						warma_add_zero(6,3,per_tempeture);
						break;
					case 1://H
						shumatmp[0] = 16;
						shumatmp[1] = 23;
						warma_add_zero(3,2,max_humidity);
						shumatmp[4] = 21;
						warma_add_zero(6,3,per_humidity);
						break;
					case 2://F
						shumatmp[0] = 15;
						warma_add_zero(2,2,reflush_count);
						if(reflush_count == 0)
						{
							shumatmp[3] = 23;shumatmp[4] = 23;
							shumatmp[5] = 23;shumatmp[6] = 23;
							shumatmp[7] = 23;
						}
						else
						{
							warma_add_zero(4,2,last_time_hour);
							shumatmp[5] = 21;
							warma_add_zero(7,2,last_time_min);
						}
						break;
				}
				break;
			
			case 2://P
				shumatmp[0] = 19;
				shumatmp[1] = 23;
				shumatmp[2] = 23;
				shumatmp[3] = 23;
				shumatmp[4] = 23;
				shumatmp[5] = 23;
				warma_add_zero(7,2,set_tempeture);
			    key_s5_flag = 0;
				break;
			
			default:
				break;
		}
	}
}