#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction16(u8 i);
void clear_ctrl();//100ms
void tempeture_ctrl();//500ms
void distance_ctrl();//500ms
void shuma_exchange_ctrl();

#endif