#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "ds18b20.h"
#include "wave.h"
#include "pcf8591.h"

void shuma_exchange_ctrl();
void led_ctrl();
void led_scan();
void dac_ctrl();

extern bit clear_flag;
extern u8 shumatmp[];

u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

u8  key_s4_flag = 0;//界面切换
u8  key_s5_flag = 0;//回显切换
bit key_s8_flag = 0;//+1 
bit key_s9_flag = 0;//-1 

u8 dac10_low = 10;
u16 v_sound = 340;
signed char len_ctrl = 0;
u8 tmp_set = 30;
u8 len_set = 40;
u16 tmp10_now = 0;
u8 dis_cm_now = 0;
u8 record_distance;

bit record_flag = 0;

void keyaction16(u8 i)
{
	if(record_flag == 0)
	{
		switch(i)
		{
			case 4:
				if(key_s4_flag == 2) key_s4_flag = 0;
				else key_s4_flag++;
				key_s5_flag = 0;
				led_ctrl();
				break;
			
			case 5:
				if(key_s4_flag == 0 || key_s4_flag == 1)
				{
					if(key_s5_flag == 0) key_s5_flag = 1;
					else key_s5_flag = 0;
				}
				if(key_s4_flag == 2)
				{
					if(key_s5_flag == 2) key_s5_flag = 0;
					else key_s5_flag++;
				}
				break;
			
			case 8:
				if(key_s4_flag == 0) record_flag = 1; 
				else if(key_s4_flag == 1)
				{
					if(key_s5_flag == 0&&len_set < 90) len_set += 10;
					if(key_s5_flag == 1&&tmp_set < 80) tmp_set ++;
				}
				else if(key_s4_flag == 2)
				{
					if(key_s5_flag == 0&&len_ctrl < 90) len_ctrl += 5;
					if(key_s5_flag == 1&&v_sound < 9990) v_sound +=10;
					if(key_s5_flag == 2&&dac10_low < 20) dac10_low ++;
				}
				break;
			
			case 9:
				if(key_s4_flag == 0) dac_ctrl();
				else if(key_s4_flag == 1)
				{
					if(key_s5_flag == 0&&len_set > 10) len_set -= 10;
					if(key_s5_flag == 1&&tmp_set > 0)  tmp_set --;
				}
				else if(key_s4_flag == 2)
				{
					if(key_s5_flag == 0&&len_ctrl > -90) len_ctrl -= 5;
					if(key_s5_flag == 1&&v_sound > 10) v_sound -=10;
					if(key_s5_flag == 2&&dac10_low > 1) dac10_low --;
				}
				break;
			
			default:
				break;
		}
	}
}

void clear_ctrl()
{
	if(clear_flag == 1)
	{
		clear_flag = 0;
		dac10_low = 10;
		v_sound = 340;
		len_ctrl = 0;
		tmp_set = 30;
		len_set = 40;
	}
	shuma_exchange_ctrl();
}

void dac_ctrl()
{
	if(dis_cm_now < 10) dac((u8)(dac10_low*5.1));
	if(dis_cm_now > 90) dac(255);
	if(dis_cm_now>10&&dis_cm_now<90) dac((u8)((50-dac10_low)*(char)dis_cm_now/800.0+((9.0*dac10_low-50)/80.0)));
}

void tempeture_ctrl()//500ms
{
	do{
			tmp10_now = (u16)(ds18b20_read_tempeture()*10.0);
		}while(tmp10_now == 0);
	shuma_exchange_ctrl();
}

void distance_ctrl()//500ms
{
	static u8 count = 0;
	do{
			dis_cm_now = receive_wave();
		}while(dis_cm_now == 99);
	
	dis_cm_now = (char)dis_cm_now/340.0*v_sound + len_ctrl;
		
	if(record_flag == 1&&count<12)
	{
		record_distance = dis_cm_now;
		count++;
	}
	else
	{
		record_flag = 0;
		count = 0;
	}
	shuma_exchange_ctrl();
	led_ctrl();
}

void led_scan()
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

void led_ctrl()
{
	static u8 a = 0;
	if(key_s4_flag == 0)
	{
		P2=(P2&0x1f)|0x80;
		P0 = ~(dis_cm_now);
		P2&=0x1f;
	}
	if(key_s4_flag == 1) {ledtmp[7] = 0;led_scan();}
	if(key_s4_flag == 2) {ledtmp[0] = a;ledtmp[7] = 0xff;led_scan();}
	if(a == 0) a = 0xff; else a = 0;
}

void shuma_exchange_ctrl()
{
	if(key_s4_flag == 0)
	{
		warma_none_zero(1,3,tmp10_now);
		shumatmp[3] = 21;
		shumatmp[4] = 23;
		if(key_s5_flag == 0) {shumatmp[5] = 23; warma_none_zero(7,2,dis_cm_now);}
		if(key_s5_flag == 1) {shumatmp[5] = 0; warma_none_zero(7,2,dis_cm_now);}
	}
	if(key_s4_flag == 1)
	{
		shumatmp[0] = 19;
	    shumatmp[2] = 23;
		shumatmp[3] = 23;
		shumatmp[4] = 23;
		shumatmp[5] = 23;
		if(key_s5_flag == 0)
		{
			shumatmp[1] = 1;
			warma_none_zero(7,2,len_set);
		}
		if(key_s5_flag == 1)
		{
			shumatmp[1] = 2;
			warma_none_zero(7,2,tmp_set);
		}
	}
	if(key_s4_flag == 2)
	{
		shumatmp[0] = 15;
	    shumatmp[2] = 23;
		shumatmp[3] = 23;
		if(key_s5_flag == 0)
		{
			shumatmp[1] = 1;
			shumatmp[4] = 23;
			if(len_ctrl<-5)
			{
				shumatmp[5] = 21;
				warma_none_zero(7,2,len_ctrl);
			}
			else if(len_ctrl == -5)
			{
				shumatmp[5] = 23;
				shumatmp[6] = 21;
				shumatmp[7] = 5;
			}
			else if(len_ctrl == 0)
			{
				shumatmp[5] = 23;
				shumatmp[6] = 23;
				shumatmp[7] = 0;
			}
			else
				warma_none_zero(6,3,len_ctrl);
		}
		if(key_s5_flag == 1)
		{
			shumatmp[1] = 2;
			warma_none_zero(5,4,v_sound);
		}
		if(key_s5_flag == 2)
		{
			shumatmp[1] = 3;
			shumatmp[4] = 23;
			shumatmp[5] = 23;
			if(dac10_low<10)
			{
				shumatmp[6] = 0;
				shumatmp[7] = dac10_low;
			}
			else warma_none_zero(7,2,dac10_low);
		}
	}
}