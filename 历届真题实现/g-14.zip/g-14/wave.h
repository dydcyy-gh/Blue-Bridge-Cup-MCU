#include "typedef.h"

#ifndef __WAVE_H__
#define __WAVE_H__

void send_wave();
u8 receive_wave();

#endif