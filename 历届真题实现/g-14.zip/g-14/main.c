#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "timer1.h"
#include "ctrl.h"

bit u1flag = 0;
bit u2flag = 0;
bit u3flag = 0;

extern bit refresh_flag;

void main()
{
	timer1init(2);
	while(1)
	{
		if(u1flag == 1)
		{
			clear_ctrl();
			u1flag = 0;
		}
		if(u2flag == 1)
		{
			tempeture_ctrl();
			u2flag = 0;
		}
		if(u3flag == 1)
		{
			distance_ctrl();
			u3flag = 0;
		}
		if(refresh_flag == 1)
		{
			refresh_flag = 0;
			shuma_exchange_ctrl();
		}
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count1=0;
	static u8 count2=0;
	static u8 count3=0;
	count1++;
	count2++;
	count3++;
	if(count1>249)
		{count1=0;u1flag = 1;}
	if(count2>249)
		{count2=0;u2flag = 1;}
	if(count3>249)
		{count3=0;u3flag = 1;}
	keyscan16();
	shumascan();
}
