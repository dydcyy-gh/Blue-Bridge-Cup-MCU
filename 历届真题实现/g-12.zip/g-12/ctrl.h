#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction16(u8 i);
void adda_ctrl();//@100ms
void ds1302_ctrl();//@100ms
void wave_ctrl();//@100ms
void led_scan();//@100ms
void led_ctrl();//@100ms
void shuma_exchange_ctrl();//@100ms

#endif