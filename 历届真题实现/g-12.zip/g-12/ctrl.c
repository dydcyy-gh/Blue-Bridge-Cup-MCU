#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "pcf8591.h"
#include "ds1302.h"
#include "wave.h"

extern u8 time[];
extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

bit key_s4_flag = 0;//界面切换
u8  key_s5_flag = 0;//回显切换
u8  key_s8_flag = 0;//模式切换
u8  key_s9_flag = 0;//调整参数

bit all_flag = 0;
bit modle_F = 0;
bit modle_C = 1;
bit light_flag = 0;
bit dark_flag = 0;
bit warning_flag = 0;
u8  length_now;
u8  length_set = 20;
u8  length_max;
u8  length_min;
u16 length_per;
u8  time_set = 2;

//所有变量都在这声明

//按键行为函数
void keyaction16(u8 i)
{
	switch(i)
	{
		case 4:
			if(key_s4_flag == 0) key_s4_flag = 1;
			else key_s4_flag = 0;
			key_s5_flag = 0;
			all_flag = 1;
			break;
		
		case 5:
			if(key_s4_flag == 0)
			{
				if(key_s5_flag == 2) key_s5_flag = 0;
				else key_s5_flag++;
			}
			if(key_s4_flag == 1)
			{
				if(key_s5_flag == 0) key_s5_flag = 1;
				else key_s5_flag = 0;
			}
			key_s8_flag = 0;
			all_flag = 1;
			break;
		
		case 8:
			if(key_s4_flag == 0 && key_s5_flag == 1)
			{
				if(modle_F == 1){ modle_F = 0; modle_C = 1;}
				else{ modle_F = 1; modle_C = 0;}
			}
			if(key_s4_flag == 0 && key_s5_flag == 2)
			{
				if(key_s8_flag == 2) key_s8_flag = 0;
				else key_s8_flag ++;
			}
			all_flag = 1;
			break;
		
		case 9:
			if(key_s4_flag == 1 && key_s5_flag == 0)
			{
				key_s9_flag = 1;
			}
			else if(key_s4_flag == 1 && key_s5_flag == 1)
			{
				key_s9_flag = 2;
			}
			else key_s9_flag = 0;
			all_flag = 1;
			break;
		
		default:
			break;
	}
}

void adda_ctrl()
{
	if(adc(0x01)>150) light_flag = 1;
	else light_flag = 0;
	if(adc(0x01)<50 ) dark_flag = 1;
	else dark_flag = 0;
	if(length_now>=80) dac(255);
	if(length_now<=10) dac(51);
	if(length_now>10 && length_now<80) 
		dac((102*length_now + 715)/35);
}

void ds1302_ctrl()
{
	DS1302_ReadTime();
}

void wave_ctrl()
{
	static u8 count = 0;
	static u16 length_sum = 0;
	static u8 all_count = 0;
	static bit last3_flag = 0,last2_flag = 0,last1_flag = 0;
	if(modle_F)
	{
		if(time[5]%time_set == 0) 
		{
			length_now = receive_wave();
			if(all_count == 0)
			{
				length_max = length_now;
				length_min = length_now; 
			}
			all_count++;
			length_sum += length_now;
			length_per = (u8)((length_sum*10)/all_count);
			if(length_now<length_set+5 && length_now>length_set-5) count++;
			else count = 0;
			if(length_now > length_max) length_max = length_now;
			if(length_now < length_min) length_min = length_now;
		}
	}
	if(modle_C)
	{
		last3_flag = last2_flag;
		last2_flag = last1_flag;
		last1_flag = light_flag;
		if(last3_flag == 1 && dark_flag == 1) 
		{
			length_now = receive_wave();
			if(all_count == 0)
			{
				length_max = length_now;
				length_min = length_now; 
			}
			all_count++;
			length_sum += length_now;
			length_per = (u8)((length_sum*10)/all_count);
			if(length_now<length_set+5 && length_now>length_set-5) count++;
			else count = 0;
			if(length_now > length_max) length_max = length_now;
			if(length_now < length_min) length_min = length_now;
		}
	}
	if(count >= 3)
	{
		count = 0;
		warning_flag = 1;
	}
}
//led刷新
void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

//led显示控制
void led_ctrl()//@100ms @timer1
{
	if(key_s4_flag == 0 && key_s5_flag == 0)
		ledtmp[0] = 0x00;
	else ledtmp[0] = 0xff;
	
	if(key_s4_flag == 0 && key_s5_flag == 1)
		ledtmp[1] = 0x00;
	else ledtmp[1] = 0xff;
	
	if(key_s4_flag == 0 && key_s5_flag == 2)
		ledtmp[2] = 0x00;
	else ledtmp[2] = 0xff;
	
	if(modle_C) ledtmp[3] = 0x00;
	else ledtmp[3] = 0xff;
	
	if(warning_flag) {ledtmp[4] = 0x00; warning_flag = 0;}
	else ledtmp[4] = 0xff;
	
	if(light_flag) {ledtmp[5] = 0x00;light_flag = 0;}
	else ledtmp[5] = 0xff;
}

//根据按键状态刷新状态，进行数码管显示
void shuma_exchange_ctrl()//@100ms @timer1
{
	if(key_s4_flag == 0)
	{
		if(key_s5_flag == 0)
		{
			warma_add_zero(1,2,time[3]);
			shumatmp[2]=21;
			warma_add_zero(4,2,time[4]);
			shumatmp[5]=21;
			warma_add_zero(7,2,time[5]);
		}
		if(key_s5_flag == 1)
		{
			shumatmp[0]=17;
			if(modle_C) shumatmp[1]=12;
			if(modle_F) shumatmp[1]=15;
			shumatmp[2]=23;
			shumatmp[3]=23;
			shumatmp[4]=23;
			warma_none_zero(6,3,length_now);
		}
		if(key_s5_flag == 2)
		{
			shumatmp[0]=16;
			shumatmp[2]=23;
			shumatmp[3]=23;
			if(key_s8_flag == 0){
				shumatmp[1]=24;
				warma_none_zero(5,4,length_max);
			}
			if(key_s8_flag == 1){
				shumatmp[1]=21;
				warma_none_zero(5,4,length_per);
			}
			if(key_s8_flag == 2){
				shumatmp[1]=25;
				warma_none_zero(5,4,length_min);
			}
		}
	}
	if(key_s4_flag == 1)
	{
		shumatmp[0]=19;
		if(key_s8_flag == 0) shumatmp[1]=12;
		if(key_s8_flag == 1) shumatmp[1]=15;
		shumatmp[2]=23;
		shumatmp[3]=23;
		shumatmp[4]=23;
		shumatmp[5]=23;
		if(key_s5_flag == 0)
		{
			shumatmp[1]=1;
			warma_add_zero(7,2,time_set);
		}
		if(key_s5_flag == 1)
		{
			shumatmp[1]=2;
			warma_add_zero(7,2,length_set);
		}
	}
	if(key_s9_flag == 1)
	{
		key_s9_flag = 0;
		switch(time_set)
		{
			case 2: time_set = 3; break;
			case 3: time_set = 5; break;
			case 5: time_set = 7; break;
			case 7: time_set = 9; break;
			case 9: time_set = 2; break;
		}
	}
	if(key_s9_flag == 2)
	{
		key_s9_flag = 0;
		if(length_set < 80) length_set += 10;
		else length_set = 10;
	}
}
