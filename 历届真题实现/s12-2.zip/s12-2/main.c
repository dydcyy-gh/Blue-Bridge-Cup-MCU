#include <STC15F2K60S2.H>
#include "typedef.h"
#include "4key.h"
#include "shuma.h"
#include "timer1.h"
#include "timer0.h"
#include "ctrl.h"

bit flag1 = 0;

void main()
{
	timer0init();
	timer1init(2);
	while(1)
	{
		if(flag1 == 1)
		{
			flag1 = 0;
			shuma_U();
		}
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count1=0;
	static u8 count2=0;
	static u8 count3=0;
	static u8 count4=0;
	count1++;
	if(count1>=100)
		{count1=0;flag1 = 1;}
	count2++;
	if(count2>=50)
		{count2=0;led_ctrl();}
	count3++;
	if(count3>=50)
		{count3=0;led_scan();}
	count4++;
	if(count4>=100)
		{count4=0;shuma_exchange_ctrl();}
	timer0_ne555();
	shumascan();
	keyscan4();
}