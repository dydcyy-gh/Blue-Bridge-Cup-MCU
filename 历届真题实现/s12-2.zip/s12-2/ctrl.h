#include "typedef.h"

#ifndef __DS18B20_H__
#define __DS18B20_H__

void keyaction4(u8 i);
void timer0_ne555();//@alltime @timer1
void shuma_U();//@200ms @main
void led_scan();//@100ms @timer1
void led_ctrl();//@100ms @timer1
void shuma_exchange_ctrl();//@200ms @timer1
	
#endif