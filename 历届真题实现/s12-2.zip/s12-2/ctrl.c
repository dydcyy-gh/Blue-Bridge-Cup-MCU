#include <STC15F2K60S2.H>
#include "typedef.h"
#include "4key.h"
#include "shuma.h"
#include "pcf8591.h"

extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};//led乱闪解决：放数组里

u8 key_s4_flag = 0;//show_exchange 0-F  1-N  2-U
u8 key_s5_flag = 0;//modle exchange  0-channel 1  1-channel 3
u8 key_s6_flag = 0;//store U only @channel 3 @all time
u8 key_s7_flag = 0;//store ne555  @all time
u8 key_s7_long_flag = 0;//led off

u16 ADC_1;
u16 ADC_3;
u16 FreqCnt = 0;
u16 ADC_3_save;
u16 FreqCnt_save;

void keyaction4(u8 i)
{
	switch(i)
	{
		case 0://show_exchange 0-F  1-N  2-U
			if(key_s4_flag == 2) key_s4_flag = 0;
			else key_s4_flag++;
			break;
		
		case 1://modle exchange  0-channel 1  1-channel 3
			if(key_s5_flag == 1) key_s5_flag = 0;
			else key_s5_flag = 1;
			break;
		
		case 2://store U only @channel 3 @all time
			ADC_3_save = ADC_3;
			break;
		
		case 3://store ne555  @all time
			FreqCnt_save = FreqCnt;
			break;
		
		case 4://s7 long_key_action
			if(key_s7_long_flag == 1) key_s7_long_flag = 0;
			else key_s7_long_flag = 1;
			break;
		
		default:
			break;
	}
}

void timer0_ne555()//@alltime @timer1
{
	static u16 AllTime = 0;
	if(AllTime == 0)          //ALLTime为计时的变量
	{
		TR0 = 1;                 //计数器0开启计数
		AllTime++;
	}
	else if(AllTime < 500)  //如果小于1s钟的话
	{
		AllTime++;
	}
	else                        //如果1s到了的话
	{
		AllTime = 0;            //清空计时变量
		TR0 = 0;                //停止计时
		FreqCnt = (((u16)TH0 << 8) |(u16)TL0); //将脉冲频率取出
		TH0 = 0;                //清除脉冲计数现有值，做好初始化
		TL0 = 0;
	}
}

void shuma_U()//@200ms @main
{	
	if(key_s5_flag == 0)//channel 1
		ADC_1 = (adc(0x01))/0.51;
	if(key_s5_flag == 1)//channel 3
		ADC_3 = (adc(0x03))/0.51;
}

void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;  
}

void led_ctrl()//@100ms @timer1
{
	u8 i;
	if(key_s7_long_flag == 0)
	{
		if(ADC_3_save < ADC_3) ledtmp[0] = 0x00;
		else ledtmp[0] = 0xff;
		if(FreqCnt_save < FreqCnt) ledtmp[1] = 0x00;
		else ledtmp[1] = 0xff;
		if(key_s4_flag == 0) ledtmp[2] = 0x00;
		else ledtmp[2] = 0xff;
		if(key_s4_flag == 1) ledtmp[3] = 0x00;
		else ledtmp[3] = 0xff;
		if(key_s4_flag == 2) ledtmp[4] = 0x00;
		else ledtmp[4] = 0xff;
	}
	if(key_s7_long_flag == 1)
	{
		for(i=0;i<8;i++)
		{
			ledtmp[i] = 0xff;
		}
	}
}


void shuma_exchange_ctrl()//@200ms @timer1
{
	switch(key_s4_flag)
	{
		case 0://0-F
			shumatmp[0] = 15;
			warma_one(FreqCnt);
			break;
		
		case 1://1-N
			shumatmp[0] = 18;
			warma_one(1000000/FreqCnt);
			break;
		
		case 2://2-U
			shumatmp[0] = 20;
			shumatmp[1] = 21;
			if(key_s5_flag == 0){
				shumatmp[2] = 1;
			    warma_two(6,3,ADC_1);}
			if(key_s5_flag == 1){
				shumatmp[2] = 3;
			    warma_two(6,3,ADC_3);}
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			break;
		
		default:
			break;
	}
}