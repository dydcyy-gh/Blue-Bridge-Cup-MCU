#include "typedef.h"

#ifndef __SHUMA_H__
#define __SHUMA_H__

void shuma(u8 locate,u8 number,u8 lens);
void warma(u8 locate,u32 num);
void shumascan();
void key_s4_all();
void keyaction4(u8 i);
void keyscan4();


#endif