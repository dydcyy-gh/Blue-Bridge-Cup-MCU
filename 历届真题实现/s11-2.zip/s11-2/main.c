#include <STC15F2K60S2.H>
#include "shuma_key.h"
#include "typedef.h"
#include "timer1.h"
#include "ds18b20.h"

u8 tempeture;

void Delay300ms(void)	//@12.000MHz
{
	unsigned char data i, j, k;
	i = 14;
	j = 174;
	k = 224;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void main()
{
	timer1init(2);
	while(1)
	{
		tempeture = (u8)ds18b20_read_tempeture();
		Delay300ms();
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count=0;
	count++;
	if(count>250)
		{count=0;key_s4_all();}
	shumascan();
	keyscan4();
	led_show();
}