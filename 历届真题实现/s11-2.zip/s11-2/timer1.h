#include "typedef.h"

#ifndef __TIMER1_H__
#define __TIMER2_H__

void timer1init(u8 ms);

#endif