#include <STC15F2K60S2.H>
#include "onewire.h"

//用到的rom命令
#define skip_rom 0xcc
//用到的功能命令
#define convent_t 0x44
#define read_scratchpad 0xbe

//简单读取函数~
float ds18b20_read_tempeture()
{
	unsigned int temp;
	float tempeture;
	unsigned char low,high;
	//convent_t
	init_ds18b20();
	Write_DS18B20(skip_rom);
	Write_DS18B20(convent_t);
	Delay_OneWire(200);//2ms
	//read_scratchpad
	init_ds18b20();
	Write_DS18B20(skip_rom);
	Write_DS18B20(read_scratchpad);
	
	low = Read_DS18B20();
	high = Read_DS18B20();
	
	//整合数据，0.0625精度
	if(high>10)//负数
	{
		high &= 0x07;
		temp = (high<<8)|low;
	    tempeture = -(temp*0.0625);
	}
	else
	{
		temp = (high<<8)|low;
		tempeture = temp*0.0625;
	}
	return tempeture;
}
