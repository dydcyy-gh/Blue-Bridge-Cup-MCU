#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "shuma.h"
#include "pcf8591.h"
#include "at24c02.h"

extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
//led乱闪解决：放数组里

bit key_s13_flag = 0;//clear @N
u8  key_s12_flag = 2;//0-U  1-P  2-N  exchange @all
bit key_s17_flag = 0;//-0.5v @p
bit key_s16_flag = 0;//+0.5v @p

u16 V3;
u16 Vp;
u8 count = 0;
u8 error_count = 0;
u8 error_led_flag = 0;

//按键行为函数（示例为数码管增加数字）
void keyaction16(u8 i)
{
	switch(i)
	{
		case 13:
			key_s13_flag = 1;
		    i=0;
			break;
		
		case 12:
			if(key_s12_flag == 2) key_s12_flag = 0;
			else key_s12_flag++;
		    error_led_flag = 0;
		    i=0;
			break;
		
		case 17:
			key_s17_flag = 1;
		    i=0;
			break;
		
		case 16:
			key_s16_flag = 1;
		    i=0;
			break;
		
		default:
			break;
	}
}

void shuma_U()//@100ms @main
{
	if(key_s12_flag != 1)
		V3 = (adc(0x03))/0.51;
}

void shuma_p_init()
{
	Vp = (AT24C02_ReadByte(0x00))*10;
}

void shuma_P()//@100ms @main
{
	u8 flag = 0;
	if(key_s12_flag == 1)
	{
		if(key_s17_flag)
		{
			key_s17_flag = 0;
			if(Vp>=50)
			{
				Vp -= 50;
				error_led_flag = 0;
			}
			else
			{
				Vp = 0;
				error_count++;
			}
			flag = 1;
		}
		if(key_s16_flag)
		{
			key_s16_flag = 0;
			if(Vp<=450)
			{
				Vp += 50;
				error_led_flag = 0;
			}
			else
			{
				Vp = 500;
				error_count++;
			}
			flag = 1;
		}
	}
	if(flag == 1&&key_s12_flag != 1)
	{
		flag = 0;
	    AT24C02_WriteByte(0x00,(u8)(Vp/10));
	}
}

void shuma_N()//@100ms @timer1
{
	static bit flag_ok = 0;
	if(V3 > Vp)
	{
		flag_ok = 1;
	}
	if(flag_ok == 1&& V3<Vp)
	{
		flag_ok = 0;
		count++;
	}
	if(count>99) count = 0;	

	if(key_s12_flag == 2)
	{
		if(key_s13_flag == 1)
		{
			key_s13_flag = 0;
			if(count != 0)
			{
				error_led_flag = 0;
				count = 0;
			}
			else error_count++;
		}
	}
}

void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

void led_ctrl()//@100ms @timer1
{
	static u8 clock;
	if(V3<Vp)
	{
		clock++;
		if(clock>=50)
		{
			clock = 0;
			ledtmp[0] = 0x00;
		}
	}
	else
	{
		clock = 0;
		ledtmp[0] = 0xff;
	}
	if(count%2 == 1)
	{
		ledtmp[1] = 0x00;
	}
	else
	{
		ledtmp[1] = 0xff;
	}
	//0-U  1-P  2-N  exchange @all
	if(key_s12_flag == 0)
	{
		if(key_s13_flag == 1)
		{
			key_s13_flag = 0;
			error_count++;
		}
		if(key_s16_flag == 1)
		{
			key_s16_flag = 0;
			error_count++;
		}
		if(key_s17_flag == 1)
		{
			key_s17_flag = 0;
			error_count++;
		}
	}
	//0-U  1-P  2-N  exchange @all
	if(key_s12_flag == 1)
	{
		if(key_s13_flag == 1)
		{
			key_s13_flag = 0;
			error_count++;
		}
	}
	//0-U  1-P  2-N  exchange @all
	if(key_s12_flag == 2)
	{
		if(key_s16_flag == 1)
		{
			key_s16_flag = 0;
			error_count++;
		}
		if(key_s17_flag == 1)
		{
			key_s17_flag = 0;
			error_count++;
		}
	}
	if(error_count>=3)
	{
		error_count = 0;
		error_led_flag = 1;
	}
	if(error_led_flag == 1)
	{
		ledtmp[2] = 0x00;
	}
	else
	{
	    ledtmp[2] = 0xff;
	}
}

void shuma_exchange_ctrl()//@300ms @timer1
{
	switch(key_s12_flag)
	{
		case 0://0-U
			shumatmp[0] = 20;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			warma(6,3,V3);
			break;
		
		case 1://1-P
			shumatmp[0] = 19;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			warma(6,3,Vp);
			break;
		
		case 2://2-N
			shumatmp[0] = 18;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			shumatmp[5] = 23;
			warma(7,2,count);
			break;
		
		default:
			break;
	}
}