#include <STC15F2K60S2.H>
#include "IIC.h"
#include "typedef.h"

#define ADDRESS	0xA0//at24c02写地址

//iicstart--iicstop 5ms延迟，但单字节读写不用
//（上电时间已大于）5ms

//AT24C02字节写
void AT24C02_WriteByte(u8 Ad,u8 Data)
{
	I2CStart();
	I2CSendByte(ADDRESS);
	I2CWaitAck();
	I2CSendByte(Ad);
	I2CWaitAck();
	I2CSendByte(Data);
	I2CWaitAck();
	I2CStop();
}

//AT24C02字节读
u8 AT24C02_ReadByte(u8 Ad)
{
	u8 Data;
	I2CStart();
	I2CSendByte(ADDRESS);
	I2CWaitAck();
	I2CSendByte(Ad);
	I2CWaitAck();
	I2CStart();
	I2CSendByte(ADDRESS|0x01);
	I2CWaitAck();
	Data=I2CReceiveByte();
	I2CSendAck(1);
	I2CStop();
	return Data;
}
