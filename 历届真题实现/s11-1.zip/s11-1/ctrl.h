#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction16(u8 i);
void shuma_U();//@100ms
void shuma_p_init();
void shuma_P();
void shuma_N();//@100ms
void shuma_exchange_ctrl();//@300ms
void led_ctrl();//@100ms @timer1
void led_scan();//@100ms @timer1

#endif