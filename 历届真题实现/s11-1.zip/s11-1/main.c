#include <STC15F2K60S2.H>
#include "timer1.h"
#include "typedef.h"
#include "shuma.h"
#include "16key.h"
#include "ctrl.h"

bit flag1 = 0;
bit flag2 = 0;

void main()
{
	timer1init(2);
	shuma_p_init();
	while(1)
	{
		if(flag1 == 1)
		{
			flag1 = 0;
			shuma_U();//@100ms @main
		}
		if(flag2 == 1)
		{
			flag2 = 0;
			shuma_P();//@100ms @main
		}
	}
}

//这里是定时器1中断函数（示例）
void interrupttimer1() interrupt 3
{
	static u8 count0 = 0;
	static u8 count1 = 0;
	static u8 count2 = 0;
	static u8 count3 = 0;
	static u8 count4 = 0;
	count0++;
	count1++;
	count2++;
	count3++;
	count4++;
	if(count0>150)
	{
		count0 = 0;
		shuma_exchange_ctrl();//@300ms
	}
	if(count1>50)
	{
		count1 = 0;
		shuma_N();//@100ms
	}
	if(count2>50)
	{
		count2 = 0;
		flag1 = 1;
	}
	if(count3>50)
	{
		count3 = 0;
		flag2 = 1;
	}
	if(count4>50)
	{
		count4 = 0;
		led_ctrl();
		led_scan();
	}
	shumascan();
	keyscan16();
}