#include <STC15F2K60S2.H>
#include "typedef.h"
#include "16key.h"
#include "pcf8591.h"
#include "ds18b20.h"
#include "ds1302.h"
#include "shuma.h"

extern u8 shumatmp[];
extern u8 time[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};

bit key_s4_flag = 0;//界面切换
u8  key_s5_flag = 0;//回显切换
bit key_s8_flag = 0;//-1
bit key_s9_flag = 0;//+1

bit light_flag = 1;
u8 time_set = 17;
u8 temp_set = 25;
u8 led_num = 4;
u8 adc_light;
u8 temp_now;//*10
bit output_flag = 0;

u8 timer = 17;
u8 temp = 25;
u8 led  = 4;

//按键行为函数
void keyaction16(u8 i)
{
	switch(i)
	{
		case 4:
			if(key_s4_flag == 0) 
				key_s4_flag = 1;
			else key_s4_flag = 0;
			key_s5_flag = 0;
			break;
		
		case 5:
			if(key_s5_flag == 2) key_s5_flag = 0;
			else key_s5_flag++;
			break;
		
		case 8:
			if(key_s4_flag == 1) key_s8_flag = 1;
			break;
		
		case 9:
			if(key_s4_flag == 1) key_s9_flag = 1;
			break;
		
		default:
			break;
	}
}

void read_ds18()
{
	temp_now = ds18b20_read_tempeture()*10;
}

void read_ds1302()
{
	DS1302_ReadTime();
}

void read_adc()
{
	do adc_light = adc(0x01);
	while(adc_light == 0);
}

void set_ctrl()
{
	static bit output_flag = 0;
	if(key_s4_flag == 1)
	{
		output_flag = 1;
		if(key_s8_flag == 1 && key_s5_flag == 0)
		{
			key_s8_flag = 0;
			if(time_set > 0) time_set--;
			else time_set = 0;
		}
		if(key_s8_flag == 1 && key_s5_flag == 1)
		{
			key_s8_flag = 0;
			if(temp_set > 0) temp_set--;
			else temp_set = 0;
		}
		if(key_s8_flag == 1 && key_s5_flag == 2)
		{
			key_s8_flag = 0;
			if(led_num > 4) led_num--;
			else led_num = 0;
		}
		if(key_s9_flag == 1 && key_s5_flag == 0)
		{
			key_s9_flag = 0;
			if(time_set < 23) time_set++;
			else time_set = 23;
		}
		if(key_s9_flag == 1 && key_s5_flag == 1)
		{
			key_s9_flag = 0;
			if(temp_set < 99) temp_set++;
			else temp_set = 99;
		}
		if(key_s9_flag == 1 && key_s5_flag == 2)
		{
			key_s9_flag = 0;
			if(led_num < 8) led_num++;
			else led_num = 8;
		}
	}
	if(key_s4_flag == 0 && output_flag == 1)
	{
		output_flag = 0;
		led  = led_num;
		temp = temp_set;
		timer = time_set;
	}
		
}

//led刷新
void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

//led显示控制
void led_ctrl()//@100ms @timer1
{
	static u8 count1 = 0;
	static u8 count2 = 0;
	
	if(time[3]>=timer || time[3]<8)
		ledtmp[0] = 0x00;
	else ledtmp[0] = 0xff;
	
	if(temp_now < temp*10)
		ledtmp[1] = 0x00;
	else ledtmp[1] = 0xff;
	
	if(light_flag == 1)
	{
		ledtmp[2] = 0x00;
		ledtmp[3] = 0xff;
		ledtmp[4] = 0xff;
		ledtmp[5] = 0xff;
		ledtmp[6] = 0xff;
		ledtmp[led-1] = 0x00;
		if(dac>150) count2++;
		else count2 = 0;
		if(count2>30) 
		{
			count2 = 0;
			light_flag = 0;
		}
	}
	if(light_flag == 0)
	{
		ledtmp[2] = 0xff;
		ledtmp[3] = 0xff;
		ledtmp[4] = 0xff;
		ledtmp[5] = 0xff;
		ledtmp[6] = 0xff;
		if(dac<100) count1++;
		else count1 = 0;
		if(count1>30)
		{
			count1 = 0;
			light_flag = 1;
		}
	}
}

//根据按键状态刷新状态，进行数码管显示
void shuma_exchange_ctrl()//@300ms @timer1
{
	if(key_s4_flag == 0)
	{
		if(key_s5_flag == 0)
		{
			warma_add_zero(1,2,time[3]);
			shumatmp[2]=0;
			warma_add_zero(4,2,time[4]);
			shumatmp[5]=0;
			warma_add_zero(7,2,time[5]);
		}
		if(key_s5_flag == 1)
		{
			shumatmp[0]=15;
			shumatmp[1]=23;
			shumatmp[2]=23;
			shumatmp[3]=23;
			shumatmp[4]=23;
			warma_add_zero(6,3,temp_now);
		}
		if(key_s5_flag == 2)
		{
			shumatmp[0]=16;
			shumatmp[1]=23;
			warma_add_zero(3,3,adc_light*100/51);
			shumatmp[5]=23;
			shumatmp[6]=23;
			shumatmp[7]=light_flag;
		}
	}
	if(key_s4_flag == 1)
	{
		if(key_s5_flag == 0)
		{
			shumatmp[0]=5;
			shumatmp[1]=4;
			shumatmp[2]=23;
			shumatmp[3]=23;
			shumatmp[4]=23;
			shumatmp[5]=23;
			warma_add_zero(7,2,time_set);
		}
		if(key_s5_flag == 1)
		{
			shumatmp[0]=5;
			shumatmp[1]=5;
			shumatmp[2]=23;
			shumatmp[3]=23;
			shumatmp[4]=23;
			shumatmp[5]=23;
			warma_add_zero(7,2,temp_set);
		}
		if(key_s5_flag == 2)
		{
			shumatmp[0]=5;
			shumatmp[1]=6;
			shumatmp[2]=23;
			shumatmp[3]=23;
			shumatmp[4]=23;
			shumatmp[5]=23;
			shumatmp[6]=23;
			warma_add_zero(8,1,led_num);
		}
	}
}
