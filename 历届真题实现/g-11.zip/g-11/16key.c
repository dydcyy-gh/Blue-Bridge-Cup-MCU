#include <STC15F2K60S2.H>
#include "ctrl.h"
#include "typedef.h"

//矩阵键盘用此声明
//IN给零，OUT为0即为按下
sbit key_in_3 = P3^2;//5  9  13 17
sbit key_in_4 = P3^3;//4  8  12 16

sbit key_out_1 = P4^4; //7  6  5  4
sbit key_out_2 = P4^2; //11 10 9  8

//矩阵键盘含义数组
u8 keymap[2][2] ={
	{5, 9},
	{4, 8}
};

//矩阵键盘扫描函数(在中断调用)
//扫描一轮耗时x*8*4ms（建议中断x=1ms）
void keyscan16()
{
	u8 i;
	static u8 key = 0;
	//2*8ms延时判断
	static u8 keytmp[2][2] = {{0xff,0xff},{0xff,0xff}};
	//防重复对比数组
	static u8 keyold[2][2] = {{1,1},{1,1}};
	static u8 keynow[2][2] = {{1,1},{1,1}};
		
	switch(key)//打开一路并关闭上一轮打开的
	{
		case 0: key_in_3 = 0; key_in_4 = 1; break;
		case 1: key_in_4 = 0; key_in_3 = 1; break;
		default : break;
	}
	
	keytmp[key][0] = (keytmp[key][0]<<1)| key_out_1;
	keytmp[key][1] = (keytmp[key][1]<<1)| key_out_2;
	
	for(i=0;i<2;i++)
	{
		if(keytmp[key][i] == 0xff)
		{
			keynow[key][i] = 1;
		}
		else if(keytmp[key][i] == 0x00)
		{
			keynow[key][i] = 0;
		}
		else {}
	}
	for(i=0;i<2;i++)
	{
		//短按控制
		if(keynow[key][i]!=keyold[key][i])
		{
			if(keynow[key][i]==1 && keyold[key][i]==0)
			{
				keyaction16(keymap[key][i]);
			}
			keyold[key][i]=keynow[key][i];
		}
	}
	if(key == 1) key = 0;
	else key = 1;
}
