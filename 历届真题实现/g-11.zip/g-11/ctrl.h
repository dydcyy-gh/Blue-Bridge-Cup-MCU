#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction16(u8 i);
void read_ds18();//500ms
void read_ds1302();//200ms
void read_adc();//300ms
void set_ctrl();//100ms
void led_scan();//@100ms
void led_ctrl();//@100ms
void shuma_exchange_ctrl();//@100ms

#endif