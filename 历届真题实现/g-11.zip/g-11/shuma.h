#include "typedef.h"

#ifndef __SHUMA_H__
#define __SHUMA_H__

void shuma(u8 locate,u8 number);
void warma_add_zero(u8 locate,u8 lens,u32 num);
void warma_none_zero(u8 locate,u8 lens,u32 num);
void shumascan();

#endif