#include "typedef.h"

#ifndef __16KEY_H__
#define __16KEY_H__

void keyscan16();

#endif