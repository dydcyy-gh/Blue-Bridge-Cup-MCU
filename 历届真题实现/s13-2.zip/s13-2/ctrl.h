#include "typedef.h"

#ifndef __CTRL_H__
#define __CTRL_H__

void keyaction4(u8 i);
void shuma_U();//@200ms @main
void shuma_P();//@100ms @timer1
void shuma_L();//@200ms @main
void led_scan();//@100ms @timer1
void led_ctrl();//@100ms @timer1
void shuma_exchange_ctrl();//@300ms @timer1

#endif