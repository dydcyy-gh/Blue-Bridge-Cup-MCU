#include <STC15F2K60S2.H>
#include "typedef.h"
#include "4key.h"
#include "shuma.h"
#include "pcf8591.h"
#include "wave.h"

extern u8 shumatmp[];
u8 ledtmp[8]={0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
//led乱闪解决：放数组里

u8  key_s4_flag = 0;//0-U  1-P  2-L
bit key_s5_flag = 0;//0-Vmax  1-Vmin @after exit P
bit key_s6_flag = 0;//+0.5  @P
bit key_s7_flag = 0;//-0.5  @p

u16 ADC;
u8 Vmax = 45;
u8 Vmin = 5;
u8 distance;
bit aaa_flag = 0;

//按键行为函数（示例为数码管增加数字）
void keyaction4(u8 i)
{
	switch(i)
	{
		case 0:
			if(key_s4_flag == 2) key_s4_flag = 0;
			else key_s4_flag++;
			break;
		
		case 1:
			if(key_s5_flag == 1) key_s5_flag = 0;
			else key_s5_flag = 1;
			break;
		
		case 2:
			key_s6_flag = 1;
			break;
		
		case 3:
			key_s7_flag = 1;
			break;
		
		default:
			break;
	}
}

void shuma_U()//@200ms @main
{
	float tmp;
	ADC = (adc(0x03))/0.51;
	if(key_s4_flag == 2) 
	{
		if(distance<=20) dac(51);
		if(distance<=80) dac(255);
		if(distance>20&&distance<80)
		{ tmp =	(distance/15) - (1/3); dac((u8)tmp);}
	}
	else dac(0);
}

void shuma_P()//@100ms @timer1
{
	if(key_s4_flag == 1)
	{
		if(key_s5_flag == 0)
		{
			if(key_s6_flag == 1)
			{
				key_s6_flag = 0;
				Vmax += 5;
				if(Vmax == 55) Vmax = 5;
			}
			if(key_s7_flag == 1)
			{
				key_s7_flag = 0;
				Vmax -= 5;
				if(Vmax == 0) Vmax = 50;
			}
		}
		if(key_s5_flag == 1)
		{
			if(key_s6_flag == 1)
			{
				key_s6_flag = 0;
				Vmin += 5;
				if(Vmin == 55) Vmin = 5;
			}
			if(key_s7_flag == 1)
			{
				key_s7_flag = 0;
				Vmin -= 5;
				if(Vmin == 0) Vmin = 50;
			}
		}
	}
}

void shuma_L()//@200ms @main
{
	static u8 count = 0;
	if(key_s4_flag == 2)
	{
		if(ADC<(Vmax*10)&&ADC>(Vmin*10))
		{
			aaa_flag = 0;
			distance = receive_wave();
		}
		if(ADC>(Vmax*10)||ADC<(Vmin*10))
		{
			count++;
		}
		if(count>20)
		{
			count = 0;
			aaa_flag = 1;
		}
	}
}

void led_scan()//@100ms @timer1
{
	u8 i;
	u8 x = 0x00;
	for(i=0;i<8;i++)
	{
		x |= (0x01<<i)&ledtmp[i];
	}
	P2=(P2&0x1f)|0x80;
	P0 = x;
	P2&=0x1f;
}

void led_ctrl()//@100ms @timer1
{
	static bit a = 0;
	if(key_s4_flag == 0)
	{
		ledtmp[0] = 0;
		ledtmp[2] = 1;
	}
	if(key_s4_flag == 1)
	{
		ledtmp[1] = 0;
		ledtmp[0] = 1;
	}
	if(key_s4_flag == 2)
	{
		ledtmp[2] = 0;
		ledtmp[1] = 1;
	}
	if(ADC<Vmax*10&&ADC>Vmin*10)
	{
		ledtmp[7] = a;
		if(a == 0) a = 1;
		else a = 0;
	}
	else ledtmp[7] = 0;
}

void shuma_exchange_ctrl()//@300ms @timer1
{
	switch(key_s4_flag)
	{
		case 0://0-U
			shumatmp[0] = 20;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			warma_add_zero(6,3,ADC);
			break;
		
		case 1://1-P
			shumatmp[0] = 19;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			warma_add_zero(4,2,Vmax);
			shumatmp[5] = 23;
			warma_add_zero(7,2,Vmin);
			break;
		
		case 2://2-L
			shumatmp[0] = 17;
			shumatmp[1] = 23;
		    shumatmp[2] = 23;
			shumatmp[3] = 23;
			shumatmp[4] = 23;
			if(distance<250)
				warma_none_zero(6,3,distance);
			if(aaa_flag == 1)
			{
				shumatmp[5] = 10;
				shumatmp[6] = 10;
				shumatmp[7] = 10;
			}
			break;
		
		default:
			break;
	}
}