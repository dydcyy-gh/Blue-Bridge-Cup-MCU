#ifndef __TYPEDEF_H__
#define __TYPEDEF_H__

typedef unsigned char u8; //0-255    0x00 - 0xff
typedef unsigned int u16; //0-65535  0x0000 - 0xffff
typedef unsigned long u32;

#endif